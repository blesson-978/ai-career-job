
function suggestCareer() {
  const interest = document.getElementById("interest").value.toLowerCase();
  let suggestion = "Try exploring different skills!";

  if (interest.includes("coding") || interest.includes("programming")) {
    suggestion = "You can become a Software Developer!";
  } else if (interest.includes("music")) {
    suggestion = "How about becoming a Music Producer or Sound Engineer?";
  } else if (interest.includes("teaching")) {
    suggestion = "Consider becoming a Teacher or Online Educator!";
  } else if (interest.includes("drawing") || interest.includes("design")) {
    suggestion = "Graphic Designer or Animator might be perfect for you!";
  }

  document.getElementById("result").innerText = suggestion;
}
